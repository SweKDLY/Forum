let isButtonOn = true;
let isEnterActive = false;

function toggleButton() {
    const button = document.getElementById("toggle-button");
    isButtonOn = !isButtonOn;

    if (isButtonOn) {
        button.classList.remove("off");
    } else {
        button.classList.add("off");
    }
}

function toggleEnter() {
    const enterButton = document.getElementById("enter-button");
    isEnterActive = !isEnterActive;

    if (isEnterActive) {
        enterButton.classList.add("active");
    } else {
        enterButton.classList.remove("active");
    }
}

function checkEnter(event) {
    if (isEnterActive && event.key === "Enter") {
        submitPost();
    }
}

function submitPost() {
    if (isButtonOn) {
        const postContent = document.getElementById('post-input').value;

        const postElement = document.createElement('div');
        postElement.className = 'post';
        postElement.innerHTML = '<p>' + postContent + '</p>';

        document.getElementById('post-feed').appendChild(postElement);

        document.getElementById('post-input').value = '';
    } else {
        console.log("Knappen är av, meddelandet skickas inte.");
    }
}

function showTextBox() {
    document.getElementById("hover-textbox").style.display = "block";
}

function hideTextBox() {
    document.getElementById("hover-textbox").style.display = "none";
}

function updateTextBoxPosition(event) {
    const textBox = document.getElementById("hover-textbox");
    
    if (event) {
        const mouseX = event.clientX;
        const mouseY = event.clientY;

        textBox.style.left = mouseX + "px";
        textBox.style.top = mouseY + "px";
    }
}